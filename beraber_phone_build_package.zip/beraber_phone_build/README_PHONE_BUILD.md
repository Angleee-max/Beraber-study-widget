# Build Beraber Study Widget APK from an Android phone

This package lets GitHub Actions build the Android project in the cloud. No computer is needed, but you will need a GitHub account and a browser.

## Steps
1. In Chrome, sign in to https://github.com/ and create a **new public repository** (for example `beraber-study-widget`). Do not add a README/license/gitignore during creation.
2. Open the repository, choose **Add file → Upload files**. Upload `beraber_study_widget_source.zip` from this package.
3. Choose **Add file → Create new file**. Name it exactly `.github/workflows/build-android.yml`.
4. Open the `build-android.yml` file in this package using any text viewer, copy all its contents, paste into GitHub's editor, and commit the file to the main branch.
5. Open the repository's **Actions** tab. If prompted, enable workflows. Choose **Build Android widget APK** and tap **Run workflow** (or wait for the automatic run after the workflow file is committed).
6. Open the completed green workflow run. Under **Artifacts**, download `beraber-study-widget-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.
7. Tap the APK to install. Android may ask you to allow Chrome to install unknown apps; only do this for the APK you just built from your own repository, and turn the permission back off afterward.
8. Long-press the home screen → Widgets → Study Week Widget.

## Important
- GitHub Actions runs the build on GitHub's cloud machines. A public repository is the easiest route for a free personal build; avoid uploading personal Beraber exports or passwords.
- This APK is a first prototype. It tracks data locally; direct automatic sync with Beraber is not implemented or verified yet.
- If the build fails, open the failed run and share the error text so the project can be corrected.
